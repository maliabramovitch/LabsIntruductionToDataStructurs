package il.ac.telhai.ds.stack;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}