package il.ac.telhai.ds.graph;

public interface Weighted {
    double getWeight();
}